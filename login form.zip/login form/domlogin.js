function myvalid() {
    username = document.getElementById('username').value;
    password = document.getElementById('password').value;
    message0 = document.getElementById('showresult0');
    message11 = document.getElementById('showresult11');
    message8 = document.getElementById('showresult8');
    message9 = document.getElementById('showresult9');
    if (username == "" && password != "") {
        message0.innerHTML = "Enter User Name  &#x2757;";
        message0.style.background = "white";
    } else if (username != "") {
        message0.innerHTML = "";
    }
    if (password == "" && username != "") {
        message11.innerHTML = "Enter password &#x2757;";
        message11.style.background = "white";
    } else if (password != "") {
        message11.innerHTML = "";
    }
    if (username == "" && password == "") {
        message8.innerHTML = " Fill Out The Columns &#x2757;";
        message8.style.background = "white";
    } else if (username != "" && password != "") {
        message8.innerHTML = "sucessfully login  &#9989;";
        message8.style.background = "white";
    }
}

function validation() {
    var a = document.getElementById('email').value;
    var b = document.getElementById('user').value;
    var c = document.getElementById('password2').value;
    var d = document.getElementById('cpassword2').value;
    message = document.getElementById('result');
    message2 = document.getElementById('result2');
    message3 = document.getElementById('result3');
    message4 = document.getElementById('result4');
    message5 = document.getElementById('result5');
    message6 = document.getElementById('result6');
    message7 = document.getElementById('result7');
    if (a == "" && b != "" && c != "" && d != "") {
        message.innerHTML = " Enter the Email &#x2757;";
        message.style.background = "white";
    } else if (a != "") {
        message.innerHTML = "";
    }
    if (b == "" && a != "" && c != "" && d != "") {
        message2.innerHTML = "  Enter user name &#x2757;";
        message2.style.background = "white";
    } else if (b != "") {
        message2.innerHTML = "";
    }

    if (c == "" && a != "" && b != "" && d != "") {
        message3.innerHTML = " Enter your Password &#x2757;";
        message3.style.background = "white";
    } else if (c != "") {
        message3.innerHTML = "";
    }

    if (d == "" && a != "" && b != "" && c != "") {
        message4.innerHTML = " Enter Confirm Pass &#x2757;";
        message4.style.background = "white";
    } else if (d != "") {
        message4.innerHTML = "";
    }

    if (c != d) {
        message5.innerHTML = "  Passwords donot match &#x2757;";
        message5.style.background = "white";
    } else if (b != "" && a != "" && c != "" && d != "") {
        message6.innerHTML = "  You Have Successfully Register &#9989;";
        message6.style.background = "white";
    } else if (b == "" && a == "" && c == "" && d == "") {
        message7.innerHTML = "  fill out the columns &#x2757;";
        message7.style.background = "white";
    }


}